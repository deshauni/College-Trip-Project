<?php
if(isset($_POST['name']))
$server = "localhost";
$username = "root";
$password = "";
$database = "trip_data";

$con = mysqli_connect($server, $username, $password, $database);

if(!$con){
    die("connection to this database failed due to" . mysqli_connect_error());
}
//echo "Connected Successfully to database"
$firstname = $_POST['firstname'];
$lastname  = $_POST['lastname'];
$emailid    = $_POST['emailid'];
$phoneno    = $_POST['phoneno'];
$gender    = $_POST['gender'];
$dt = $_POST['dt'];

$sql = "INSERT INTO 'trip_data'.`candidates` (`firstname`, `lastname`, `emailid`, `phoneno`, `gender`, `dt`) 
VALUES ('$firstname', '$lastname', '$emailid', '$phoneno', '$gender', current_timestamp());";
echo $sql;
if($con->query($sql)== true){
    echo "Succesfully Inserted";
}
else{
    echo "ERROR";
}
$con->close();

?>

<!DOCTYPE html>
<html lang=eng>
<head>
<title>
Registration Form
</title>
<style>
html, body{
	width:100%;
	height:100%;
	margin:0%;
	font-family:"helvetica","verdana","calibri", "san serif";
	overflow:hidden;
	padding:0%;
	border:0%;
	}
#fo{
text-align:center;
height: 5%;

}
br{
line-height:200%;
}
input[type="text"]{
width:20%;
height: 30px;
margin:1%;
}


#di{
height:5%;
background-color:#343434;
margin-bottom:2%;
color: aqua;
text-align: center;

}
</style>
</head>
<body bgcolor="#e5a010">
   <center><h2>Trip Registration Form </h2></center> 



<div id=di>
   <p>Enter Your Details and Confirm your Availability for the Trip</p>

</div>
<div id=fo>

<form action=index.php  method=post onsubmit="return validateForm()">
<input type=text placeholder=firstname id=firstname name=firstname required><br>
<input type=text placeholder=lastname id=lastname name=lastname required><br>
<input type=text placeholder=emailid  id=emailid name=emailid required><br>
<input type=text placeholder="phoneno" id=phoneno name=phoneno required><br>
<input type=text placeholder=gender id=gender name=gender required><br>



<input type="button" onclick ="alert('Thank You Form Submitting the Information')" value="Submit">


</form>

</div>



</body>

</html>